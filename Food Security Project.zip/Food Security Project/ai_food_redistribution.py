# ============================================
# AI FOOD REDISTRIBUTION PROJECT (ROBUST SCRIPT)
# ============================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error

from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

# ============================================
# 1. LOAD DATA
# ============================================
df = pd.read_csv("SriLanka_Surplus_Prediction_Dataset.csv")

print("\nColumns in dataset:")
print(df.columns)

# ============================================
# 2. AUTO-DETECT TARGET COLUMN
# ============================================

possible_targets = ['surplus_quantity', 'food_waste', 'waste', 'waste_kg', 'quantity']

target_column = None
for col in possible_targets:
    if col in df.columns:
        target_column = col
        break

if target_column is None:
    # fallback: choose last numeric column
    numeric_cols = df.select_dtypes(include=np.number).columns
    target_column = numeric_cols[-1]

print(f"\nUsing target column: {target_column}")

# ============================================
# 3. HANDLE MISSING VALUES
# ============================================
df.fillna(df.mean(numeric_only=True), inplace=True)

# ============================================
# 4. HANDLE DATE (OPTIONAL)
# ============================================
if 'date' in df.columns:
    df['date'] = pd.to_datetime(df['date'], errors='coerce')
    df['month'] = df['date'].dt.month
    df['day'] = df['date'].dt.day
    df.drop(columns=['date'], inplace=True)

# ============================================
# 5. HANDLE CATEGORICAL DATA
# ============================================
categorical_cols = df.select_dtypes(include=['object']).columns
df = pd.get_dummies(df, columns=categorical_cols, drop_first=True)

# ============================================
# 6. FEATURE / TARGET SPLIT
# ============================================
X = df.drop(columns=[target_column])
y = df[target_column]

# ============================================
# 7. TRAIN TEST SPLIT
# ============================================
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# ============================================
# 8. MODEL TRAINING
# ============================================
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

predictions = model.predict(X_test)

# ============================================
# 9. EVALUATION
# ============================================
mae = mean_absolute_error(y_test, predictions)
rmse = np.sqrt(mean_squared_error(y_test, predictions))

print("\nModel Performance:")
print("MAE:", mae)
print("RMSE:", rmse)

# ============================================
# 10. CLUSTERING (WASTE HOTSPOTS)
# ============================================
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

kmeans = KMeans(n_clusters=3, random_state=42)
df['cluster'] = kmeans.fit_predict(X_scaled)

print("\nCluster Counts:")
print(df['cluster'].value_counts())

# ============================================
# 11. SIMULATED NGO MATCHING
# ============================================
ngos = pd.DataFrame({
    'ngo_name': ['RedCross', 'Sarvodaya', 'FoodBank_SL'],
    'demand': [100, 150, 200]
})

def assign_ngo(cluster_id):
    return ngos.iloc[cluster_id % len(ngos)]['ngo_name']

df['assigned_ngo'] = df['cluster'].apply(assign_ngo)

# ============================================
# 12. IMPACT CALCULATION
# ============================================
total_surplus = df[target_column].sum()

# Assume 0.5kg per meal
meals = total_surplus / 0.5

print("\nImpact:")
print("Total Surplus:", total_surplus)
print("Estimated Meals:", int(meals))

# ============================================
# 13. FEATURE IMPORTANCE
# ============================================
importances = model.feature_importances_
features = X.columns

feat_imp = pd.Series(importances, index=features).sort_values(ascending=False)

print("\nTop Features:")
print(feat_imp.head(10))

# ============================================
# 14. VISUALIZATION
# ============================================

# Target distribution
plt.figure()
y.hist()
plt.title("Target Distribution")
plt.show()

# Feature importance
plt.figure()
feat_imp.head(10).plot(kind='bar')
plt.title("Top Features")
plt.show()

# Clusters
plt.figure()
plt.scatter(X_scaled[:, 0], X_scaled[:, 1], c=df['cluster'])
plt.title("Clusters")
plt.show()

# ============================================
# 15. SAVE OUTPUT
# ============================================
df.to_csv("final_output.csv", index=False)

print("\n✅ SUCCESS: Script ran completely!")