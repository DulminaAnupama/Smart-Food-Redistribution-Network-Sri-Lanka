import pandas as pd
import os

# Define the folder where your CSVs are
data_folder = "Data Sets" 

def prepare_dataset():
    # 1. Check if the folder exists
    if not os.path.exists(data_folder):
        print(f"Error: I cannot find the folder named '{data_folder}'. Please create it.")
        return

    # List of required files
    files = {
        "fao": "FAOSTAT_data_en_5-5-2026.csv",
        "gdp": "sl gdp.csv",
        "pop": "sl population.csv",
        "urb": "Sl urban populaton .csv"
    }

    # Verify every file exists before starting
    for key, name in files.items():
        path = os.path.join(data_folder, name)
        if not os.path.exists(path):
            print(f"Error: Missing file -> {path}")
            return
        print(f"Found: {name}")

    print("All files found! Starting data merge...")

    # 2. Process FAO Food Data
    df_fao = pd.read_csv(os.path.join(data_folder, files["fao"]))
    df_food = df_fao.pivot_table(
        index=['Year', 'Item'], 
        columns='Element', 
        values='Value', 
        aggfunc='sum'
    ).reset_index()

    df_food = df_food.rename(columns={
        'Item': 'Food_Type',
        'Production': 'Production',
        'Import Quantity': 'Imports',
        'Food': 'Consumption',
        'Losses': 'Loss'
    })

    # 3. Clean World Bank Files
    def clean_wb(path, label):
        df = pd.read_csv(path, skiprows=4)
        melted = df.melt(id_vars=['Country Name'], var_name='Year', value_name=label)
        melted['Year'] = pd.to_numeric(melted['Year'], errors='coerce')
        return melted[['Year', label]].dropna()

    df_gdp = clean_wb(os.path.join(data_folder, files["gdp"]), 'GDP')
    df_pop = clean_wb(os.path.join(data_folder, files["pop"]), 'Population')
    df_urb = clean_wb(os.path.join(data_folder, files["urb"]), 'Urban_%')

    # 4. Merge
    final_df = df_food.merge(df_pop, on='Year', how='left') \
                      .merge(df_urb, on='Year', how='left') \
                      .merge(df_gdp, on='Year', how='left')

    # 5. Final Output
    output_name = "SriLanka_Surplus_Prediction_Dataset.csv"
    final_df.to_csv(output_name, index=False)
    
    print("-" * 30)
    print(f"SUCCESS! Your file is here: {os.path.abspath(output_name)}")
    print("-" * 30)

if __name__ == "__main__":
    prepare_dataset()