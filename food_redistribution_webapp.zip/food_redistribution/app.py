"""
app.py — Main entry point for the Smart Food Redistribution Web App.

Run with:  streamlit run app.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))

import streamlit as st
import warnings
warnings.filterwarnings("ignore")

from utils.data_generator import generate_supplier_data, generate_ngo_data
from utils.preprocessing  import preprocess
from models.ml_models     import train_models
from models.optimizer     import optimize_matching
from models.kpi           import compute_kpis

st.set_page_config(
    page_title="Smart Food Redistribution — Sri Lanka",
    page_icon="🍽️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ──────────────────────────────────────────────────────────────
st.markdown("""
<style>
[data-testid="stAppViewContainer"] { background: #0a0f0d; }
[data-testid="stSidebar"]          { background: #0f1a12; border-right: 1px solid #1e3025; }
.stMetric label { font-size: 0.75rem !important; color: #7aab8a !important; }
.stMetric [data-testid="stMetricValue"] { font-size: 1.6rem !important; color: #00ffa3 !important; font-family: 'Courier New', monospace; }
div[data-testid="stMarkdownContainer"] h1 { color: #e2f0e8; }
div[data-testid="stMarkdownContainer"] h2 { color: #a3e635; }
div[data-testid="stMarkdownContainer"] h3 { color: #22c55e; }
.stButton > button[kind="primary"] { background: #00ffa3 !important; color: #000 !important; font-weight: 700 !important; border: none !important; }
.stButton > button { border: 1px solid #1e3025 !important; color: #e2f0e8 !important; background: #111a15 !important; }
.stSelectbox label, .stCheckbox label, .stSlider label, .stNumberInput label { color: #7aab8a !important; }
</style>
""", unsafe_allow_html=True)

# ── Sidebar ─────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🍽️ Food Redistribution\n**Sri Lanka · UN SDG 2**")
    st.divider()

    st.markdown("### ⚙️ Pipeline Settings")
    n_suppliers = st.slider("Number of Suppliers", 100, 1000, 300, 50)
    n_ngos      = st.slider("Number of NGOs",       20,  120,  60,  10)
    seed        = st.number_input("Random Seed", value=42, step=1)
    run_btn     = st.button("🚀 Run Full Pipeline", type="primary", use_container_width=True)

    st.divider()
    st.markdown("### 📋 Navigation")
    st.markdown("""
- 🏠 **Home** — Pipeline launcher
- 📊 **Dashboard** — KPIs & EDA charts
- 🗺️ **Map** — Geographic view
- 🤖 **ML Models** — Model results
- 🔗 **Matching** — Optimization results
- ⚡ **Simulation** — Live dispatch loop
- ⚖️ **Ethics** — Ethical framework
    """)
    st.divider()
    st.caption("Built with Streamlit · scikit-learn · Plotly · Folium")

# ── Home page ────────────────────────────────────────────────────────────────
st.title("🍽️ Smart Food Redistribution Network — Sri Lanka")
st.markdown("""
> **UN SDG 2: Zero Hunger** · AI-powered surplus prediction + dynamic redistribution

This system predicts surplus food from urban suppliers (restaurants, hotels, supermarkets)
and dynamically matches it to NGOs and food banks across 8 Sri Lankan cities using
**Machine Learning** (Random Forest + Gradient Boosting) and the **Hungarian Algorithm**.
""")

c1, c2, c3 = st.columns(3)
c1.info("**Step 1** — Generate synthetic supplier & NGO data")
c2.info("**Step 2** — Train ML models to predict surplus food")
c3.info("**Step 3** — Optimize redistribution matching & compute KPIs")

st.markdown("### 👈 Configure settings in the sidebar and click **Run Full Pipeline**")

# ── Run Pipeline ─────────────────────────────────────────────────────────────
if run_btn:
    with st.status("🔄 Running pipeline...", expanded=True) as status:

        st.write("📦 Generating supplier and NGO data...")
        suppliers_raw = generate_supplier_data(n=n_suppliers, seed=int(seed))
        ngos          = generate_ngo_data(n=n_ngos, seed=int(seed))
        st.write(f"   ✅ {len(suppliers_raw)} suppliers · {len(ngos)} NGOs generated")

        st.write("🔧 Preprocessing (encoding + scaling)...")
        suppliers_proc, features, scaler, le_type, le_food, le_season = preprocess(suppliers_raw)
        st.write("   ✅ Categorical encoding + StandardScaler applied")

        st.write("🤖 Training ML models...")
        best_model, rf, gb, rf_r, gb_r, best_name, fi, X_test, y_test = train_models(suppliers_proc)
        st.write(f"   ✅ Best model: **{best_name}** · R² = {max(rf_r['R2'], gb_r['R2']):.4f}")

        st.write("🔗 Running redistribution optimization (Hungarian Algorithm)...")
        matches = optimize_matching(suppliers_raw, ngos)
        st.write(f"   ✅ {len(matches)} matches · {matches['allocated_kg'].sum():.0f} kg allocated")

        st.write("📊 Computing KPIs & social impact...")
        kpis = compute_kpis(suppliers_raw, matches)
        st.write(f"   ✅ {kpis['Meals Saved']:,} meals saved · {kpis['Efficiency (%)']:.1f}% efficiency")

        # Store in session state for all pages
        st.session_state.suppliers       = suppliers_raw
        st.session_state.suppliers_proc  = suppliers_proc
        st.session_state.ngos            = ngos
        st.session_state.matches         = matches
        st.session_state.kpis            = kpis
        st.session_state.best_model      = best_model
        st.session_state.scaler          = scaler
        st.session_state.le_type         = le_type
        st.session_state.le_food         = le_food
        st.session_state.le_season       = le_season
        st.session_state.rf_results      = rf_r
        st.session_state.gb_results      = gb_r
        st.session_state.best_name       = best_name
        st.session_state.feature_importance = fi
        st.session_state.X_test         = X_test
        st.session_state.y_test         = y_test

        status.update(label="✅ Pipeline complete! Navigate to any page from the sidebar.", state="complete")

# ── Show results summary if pipeline has been run ─────────────────────────────
if "kpis" in st.session_state:
    st.divider()
    st.subheader("📊 Current Run — Quick Summary")
    kpis = st.session_state.kpis
    icons = ["📦","🚚","⚡","🍽️","📍","♻️","🏪","🏥","✅"]
    cols  = st.columns(3)
    for i, (k, v) in enumerate(kpis.items()):
        cols[i % 3].metric(f"{icons[i]}  {k}", f"{v:,}" if isinstance(v, int) else v)

    st.divider()
    st.subheader("🔗 Sample Matches (Top 10)")
    m = st.session_state.matches
    display = m[["supplier_id","supplier_city","ngo_id","ngo_city",
                  "food_type","allocated_kg","distance_km","urgency_level","food_compatible"]].head(10).copy()
    display["urgency_level"]   = display["urgency_level"].map({1:"🟢 Low",2:"🟠 Medium",3:"🔴 High"})
    display["food_compatible"] = display["food_compatible"].map({True:"✅",False:"❌"})
    st.dataframe(display, use_container_width=True, hide_index=True)
    st.caption("👈 Use the sidebar to navigate to full detailed pages")
