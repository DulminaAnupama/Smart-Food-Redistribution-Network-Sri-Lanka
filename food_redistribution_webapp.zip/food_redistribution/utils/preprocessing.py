"""utils/preprocessing.py"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler
from config import SUPPLIER_TYPES, FOOD_TYPES, SEASONS, FEATURE_COLS

def preprocess(df):
    le_type   = LabelEncoder().fit(SUPPLIER_TYPES)
    le_food   = LabelEncoder().fit(FOOD_TYPES)
    le_season = LabelEncoder().fit(SEASONS)
    df = df.copy()
    df["type_enc"]   = le_type.transform(df["type"])
    df["food_enc"]   = le_food.transform(df["food_type"])
    df["season_enc"] = le_season.transform(df["season"])
    scaler = StandardScaler()
    df[FEATURE_COLS] = scaler.fit_transform(df[FEATURE_COLS])
    return df, FEATURE_COLS, scaler, le_type, le_food, le_season
