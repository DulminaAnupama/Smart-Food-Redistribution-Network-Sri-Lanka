"""utils/data_generator.py"""
import numpy as np
import pandas as pd
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from config import CITIES, SUPPLIER_TYPES, FOOD_TYPES, SEASONS, BASE_PRODUCTION

def generate_supplier_data(n=300, seed=42):
    np.random.seed(seed)
    records = []
    city_names = list(CITIES.keys())
    for i in range(n):
        city = np.random.choice(city_names)
        lat, lon, density = CITIES[city]
        stype    = np.random.choice(SUPPLIER_TYPES, p=[0.50, 0.30, 0.20])
        ftype    = np.random.choice(FOOD_TYPES)
        ts       = pd.Timestamp("2024-01-01") + pd.Timedelta(days=int(np.random.randint(0, 365)))
        produced = max(20.0, BASE_PRODUCTION[stype] + np.random.normal(0, 20))
        sell_pct = float(np.clip(0.55 + 0.25 * density + np.random.normal(0, 0.08), 0.30, 0.95))
        sold     = produced * sell_pct
        surplus  = max(0.0, produced - sold)
        records.append({
            "supplier_id": f"SUP_{i:04d}", "type": stype, "city": city,
            "latitude": round(lat + np.random.normal(0, 0.05), 4),
            "longitude": round(lon + np.random.normal(0, 0.05), 4),
            "food_type": ftype, "daily_food_produced": round(produced, 1),
            "daily_food_sold": round(sold, 1), "surplus_food": round(surplus, 1),
            "timestamp": ts.strftime("%Y-%m-%d"), "day_of_week": int(ts.dayofweek),
            "month": int(ts.month), "season": SEASONS[(ts.month % 12) // 3],
            "population_density": density,
        })
    return pd.DataFrame(records)

def generate_ngo_data(n=60, seed=42):
    np.random.seed(seed + 1)
    records = []
    city_names = list(CITIES.keys())
    for i in range(n):
        city = np.random.choice(city_names)
        lat, lon, _ = CITIES[city]
        records.append({
            "ngo_id": f"NGO_{i:03d}", "city": city,
            "latitude": round(lat + np.random.normal(0, 0.06), 4),
            "longitude": round(lon + np.random.normal(0, 0.06), 4),
            "capacity": round(float(np.random.uniform(20, 120)), 1),
            "food_type_needed": np.random.choice(FOOD_TYPES + ["any"]),
            "urgency_level": int(np.random.choice([1, 2, 3], p=[0.20, 0.50, 0.30])),
        })
    return pd.DataFrame(records)
