"""models/optimizer.py"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment
from utils.haversine import haversine
from config import SURPLUS_THRESHOLD_KG

def build_cost_matrix(active, ngos):
    n_s, n_g = len(active), len(ngos)
    cost = np.zeros((n_s, n_g))
    for i, (_, s) in enumerate(active.iterrows()):
        for j, (_, g) in enumerate(ngos.iterrows()):
            dist         = haversine(s.latitude, s.longitude, g.latitude, g.longitude)
            food_penalty = 1 if g.food_type_needed in ("any", s.food_type) else 5
            urgency_off  = (4 - g.urgency_level) * 2
            cost[i, j]   = dist * food_penalty + urgency_off
    return cost

def optimize_matching(suppliers_df, ngos_df, surplus_threshold=SURPLUS_THRESHOLD_KG):
    active = suppliers_df[suppliers_df["surplus_food"] >= surplus_threshold].copy().reset_index(drop=True)
    ngos_w = ngos_df.copy().reset_index(drop=True)
    if active.empty:
        return pd.DataFrame()
    cost = build_cost_matrix(active, ngos_w)
    row_ind, col_ind = linear_sum_assignment(cost)
    records = []
    for r, c in zip(row_ind, col_ind):
        s = active.iloc[r]; g = ngos_w.iloc[c]
        dist      = haversine(s.latitude, s.longitude, g.latitude, g.longitude)
        allocated = min(float(s.surplus_food), float(g.capacity))
        records.append({
            "supplier_id": s.supplier_id, "ngo_id": g.ngo_id,
            "supplier_city": s.city, "ngo_city": g.city,
            "food_type": s.food_type, "surplus_available": round(float(s.surplus_food),1),
            "allocated_kg": round(allocated,1), "distance_km": round(dist,2),
            "urgency_level": int(g.urgency_level),
            "food_compatible": bool(g.food_type_needed in ("any", s.food_type)),
            "sup_lat": float(s.latitude), "sup_lon": float(s.longitude),
            "ngo_lat": float(g.latitude), "ngo_lon": float(g.longitude),
        })
    return pd.DataFrame(records)
