"""models/ml_models.py"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import math
import pandas as pd
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from config import FEATURE_COLS

def train_models(suppliers_proc):
    X = suppliers_proc[FEATURE_COLS].values
    y = suppliers_proc["surplus_food"].values
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=42)

    rf = RandomForestRegressor(n_estimators=150, max_depth=10, random_state=42)
    rf.fit(X_train, y_train)
    rf_pred = rf.predict(X_test)

    gb = GradientBoostingRegressor(n_estimators=150, learning_rate=0.08, max_depth=5, random_state=42)
    gb.fit(X_train, y_train)
    gb_pred = gb.predict(X_test)

    def metrics(name, y_true, y_pred):
        mae  = mean_absolute_error(y_true, y_pred)
        rmse = math.sqrt(mean_squared_error(y_true, y_pred))
        r2   = r2_score(y_true, y_pred)
        return {"model": name, "MAE": round(mae,2), "RMSE": round(rmse,2), "R2": round(r2,4)}

    rf_r = metrics("Random Forest", y_test, rf_pred)
    gb_r = metrics("Gradient Boosting", y_test, gb_pred)

    best_model = gb if gb_r["R2"] >= rf_r["R2"] else rf
    best_name  = "Gradient Boosting" if gb_r["R2"] >= rf_r["R2"] else "Random Forest"
    fi = sorted(zip(FEATURE_COLS, rf.feature_importances_), key=lambda x: -x[1])

    return best_model, rf, gb, rf_r, gb_r, best_name, fi, X_test, y_test

def predict_surplus(model, scaler, encoded_row, features):
    df_row = pd.DataFrame([encoded_row])[features]
    scaled = scaler.transform(df_row)
    return max(0.0, float(model.predict(scaled)[0]))
