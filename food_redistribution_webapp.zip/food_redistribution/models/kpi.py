"""models/kpi.py"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import pandas as pd
from config import AVG_MEAL_WEIGHT_KG, SURPLUS_THRESHOLD_KG

def compute_kpis(suppliers, matches):
    total_surplus = float(suppliers["surplus_food"].sum())
    total_alloc   = float(matches["allocated_kg"].sum()) if not matches.empty else 0.0
    efficiency    = (total_alloc / total_surplus * 100) if total_surplus > 0 else 0.0
    return {
        "Total Surplus (kg)":     round(total_surplus, 1),
        "Total Allocated (kg)":   round(total_alloc, 1),
        "Efficiency (%)":         round(efficiency, 1),
        "Meals Saved":            int(round(total_alloc / AVG_MEAL_WEIGHT_KG)),
        "Avg Distance (km)":      round(float(matches["distance_km"].mean()), 2) if not matches.empty else 0.0,
        "Waste Reduction (%)":    round(efficiency, 1),
        "Active Suppliers":       int(len(suppliers[suppliers["surplus_food"] >= SURPLUS_THRESHOLD_KG])),
        "NGOs Served":            int(len(matches)),
        "Food Compatibility (%)": round(matches["food_compatible"].mean()*100,1) if not matches.empty else 0.0,
    }
