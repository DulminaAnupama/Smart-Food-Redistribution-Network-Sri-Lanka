"""
config.py — Global constants shared across all modules.
"""

CITIES = {
    "Colombo":       (6.9271,  79.8612, 0.95),
    "Kandy":         (7.2906,  80.6337, 0.65),
    "Galle":         (6.0535,  80.2210, 0.50),
    "Jaffna":        (9.6615,  80.0255, 0.40),
    "Negombo":       (7.2081,  79.8358, 0.55),
    "Anuradhapura":  (8.3114,  80.4037, 0.35),
    "Trincomalee":   (8.5874,  81.2152, 0.30),
    "Batticaloa":    (7.7170,  81.7000, 0.28),
}

SUPPLIER_TYPES = ["restaurant", "hotel", "supermarket"]
FOOD_TYPES     = ["cooked_meals", "fresh_produce", "bakery", "dairy", "dry_goods"]
SEASONS        = ["dry_season", "monsoon", "festival", "normal"]

BASE_PRODUCTION = {
    "restaurant":   80,
    "hotel":       200,
    "supermarket": 150,
}

FEATURE_COLS = [
    "type_enc", "food_enc",
    "daily_food_produced", "daily_food_sold",
    "day_of_week", "month", "season_enc",
    "population_density", "latitude", "longitude",
]

SURPLUS_THRESHOLD_KG = 5.0
AVG_MEAL_WEIGHT_KG   = 0.35
