"""pages/2_Map.py — Geographic Map with Folium"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import streamlit as st
import folium
from streamlit_folium import st_folium

st.set_page_config(page_title="Geographic Map", page_icon="🗺️", layout="wide")
st.title("🗺️ Geographic Distribution — Suppliers & NGOs")

if "suppliers" not in st.session_state:
    st.warning("⚠️ Please run the pipeline from the **Home** page first.")
    st.stop()

suppliers = st.session_state.suppliers
ngos      = st.session_state.ngos
matches   = st.session_state.matches

col1, col2, col3 = st.columns(3)
col1.metric("Total Suppliers", len(suppliers))
col2.metric("Total NGOs", len(ngos))
col3.metric("Matched Routes", len(matches))

st.subheader("Map Controls")
show_suppliers = st.checkbox("Show Suppliers", value=True)
show_ngos      = st.checkbox("Show NGOs", value=True)
show_routes    = st.checkbox("Show Delivery Routes (top 30)", value=True)
filter_city    = st.selectbox("Filter by City", ["All"] + sorted(suppliers["city"].unique().tolist()))

# Build map
m = folium.Map(location=[7.8731, 80.7718], zoom_start=7,
               tiles="CartoDB dark_matter")

URGENCY_COLORS = {1: "green", 2: "orange", 3: "red"}

sup_data = suppliers if filter_city == "All" else suppliers[suppliers["city"] == filter_city]
ngo_data = ngos      if filter_city == "All" else ngos[ngos["city"] == filter_city]

if show_suppliers:
    for _, s in sup_data.iterrows():
        folium.CircleMarker(
            location=[s.latitude, s.longitude], radius=5,
            color="#00ffa3", fill=True, fill_color="#00ffa3", fill_opacity=0.7,
            tooltip=folium.Tooltip(
                f"<b>{s.supplier_id}</b><br>{s.type} | {s.city}<br>"
                f"Surplus: <b>{s.surplus_food} kg</b><br>Food: {s.food_type}"
            )
        ).add_to(m)

if show_ngos:
    for _, g in ngo_data.iterrows():
        color = URGENCY_COLORS.get(g.urgency_level, "blue")
        folium.Marker(
            location=[g.latitude, g.longitude],
            icon=folium.Icon(color=color, icon="home", prefix="fa"),
            tooltip=folium.Tooltip(
                f"<b>{g.ngo_id}</b><br>{g.city}<br>"
                f"Capacity: <b>{g.capacity} kg</b><br>"
                f"Urgency: {'🔴 High' if g.urgency_level==3 else '🟠 Medium' if g.urgency_level==2 else '🟢 Low'}<br>"
                f"Needs: {g.food_type_needed}"
            )
        ).add_to(m)

if show_routes and not matches.empty:
    route_data = matches if filter_city == "All" else matches[
        (matches["supplier_city"] == filter_city) | (matches["ngo_city"] == filter_city)
    ]
    for _, r in route_data.head(30).iterrows():
        folium.PolyLine(
            locations=[[r.sup_lat, r.sup_lon],[r.ngo_lat, r.ngo_lon]],
            color="#22c55e", weight=1.5, opacity=0.6, dash_array="6 4",
            tooltip=f"{r.supplier_id} → {r.ngo_id} | {r.allocated_kg} kg | {r.distance_km} km"
        ).add_to(m)

# Legend
legend_html = """
<div style="position:fixed;bottom:30px;left:30px;z-index:1000;background:#1a1a2e;
     padding:12px 16px;border-radius:8px;border:1px solid #333;font-size:12px;color:#eee;">
  <b>Legend</b><br>
  <span style="color:#00ffa3">●</span> Supplier &nbsp;
  <span style="color:green">⌂</span> NGO Low &nbsp;
  <span style="color:orange">⌂</span> NGO Med &nbsp;
  <span style="color:red">⌂</span> NGO High<br>
  <span style="color:#22c55e">- - -</span> Delivery Route
</div>"""
m.get_root().html.add_child(folium.Element(legend_html))

st_folium(m, width=None, height=600, returned_objects=[])
