"""pages/6_Ethics_Architecture.py"""
import streamlit as st

st.set_page_config(page_title="Ethics & Architecture", page_icon="⚖️", layout="wide")
st.title("⚖️ Ethical Considerations & System Architecture")

tab1, tab2 = st.tabs(["⚖️ Ethics", "🏗️ Architecture"])

with tab1:
    st.subheader("Ethical Framework")
    ethics = {
        "🔒 Data Privacy": "Supplier inventory is commercially sensitive. Role-based access enforced — NGOs see only allocation requests, not financials. All logs anonymised. GDPR-aligned 90-day retention policy applied.",
        "🌍 Urban vs Rural Bias": "Training data over-represents dense cities. Mitigation: stratified sampling, separate rural calibration curves, and quarterly bias audits using SHAP value drift detection.",
        "⚖️ Fair Distribution": "Urgency level (1–3) encodes community need. Cost matrix penalises low-urgency assignments. Monthly equity report tracks allocation proportional to district need.",
        "🔍 Transparency": "Each NGO assignment explains distance, food-type match, and urgency score. Suppliers receive weekly surplus-contribution summaries. Public impact dashboard shows meals saved by district.",
        "🤝 Consent & Trust": "Suppliers opt in voluntarily. NGOs can decline allocations without penalty. Community liaisons mediate disputes; no automated enforcement."
    }
    for topic, text in ethics.items():
        with st.expander(topic, expanded=True):
            st.write(text)

    st.subheader("📋 Policy Recommendations")
    st.markdown("""
    1. **Government Partnership** — Mandate surplus reporting for hotels/restaurants >50 covers/day
    2. **Tax Incentives** — Offer VAT relief for verified food donations to registered NGOs
    3. **Standardised API** — Common data format across POS systems for real-time surplus reporting
    4. **Rural Equity Fund** — Dedicated transport subsidy for Trincomalee, Batticaloa, Jaffna routes
    5. **Quarterly Audits** — Independent bias audit of redistribution decisions by district
    """)

with tab2:
    st.subheader("5-Layer System Architecture")
    st.markdown("""
    ```
    ┌─────────────────────────────────────────────────────────────┐
    │                   DATA LAYER  (Layer 1)                     │
    │  CSV / PostgreSQL — suppliers, NGOs, external feeds          │
    │  Ingestion: REST webhooks + nightly batch ETL               │
    └──────────────────────┬──────────────────────────────────────┘
                           │
    ┌──────────────────────▼──────────────────────────────────────┐
    │              ML MODEL LAYER  (Layer 2)                       │
    │  GradientBoostingRegressor  — surplus prediction             │
    │  RandomForestRegressor      — ensemble / fallback            │
    │  LSTM extension             — 7-day ahead forecasting        │
    └──────────────────────┬──────────────────────────────────────┘
                           │
    ┌──────────────────────▼──────────────────────────────────────┐
    │           OPTIMIZATION ENGINE  (Layer 3)                     │
    │  Hungarian algorithm — supplier → NGO matching               │
    │  Haversine distance + urgency + food-type constraints        │
    └──────────────────────┬──────────────────────────────────────┘
                           │
    ┌──────────────────────▼──────────────────────────────────────┐
    │                  API LAYER  (Layer 4)                        │
    │  FastAPI endpoints:                                          │
    │    POST /api/suppliers/report                                │
    │    GET  /api/predict/surplus/{id}                            │
    │    POST /api/match/optimize                                  │
    │    GET  /api/kpis/daily                                      │
    └──────────────────────┬──────────────────────────────────────┘
                           │
    ┌──────────────────────▼──────────────────────────────────────┐
    │              FRONTEND DASHBOARD  (Layer 5)                   │
    │  This Streamlit app                                          │
    │  • Folium map · Charts · Matching table · Simulation         │
    └─────────────────────────────────────────────────────────────┘
    ```
    """)

    st.subheader("📁 Project File Structure")
    st.code("""
food_redistribution/
├── app.py                      ← Main entry point (run this)
├── config.py                   ← Constants & parameters
├── requirements.txt            ← pip dependencies
│
├── utils/
│   ├── data_generator.py       ← Synthetic data generation
│   ├── preprocessing.py        ← Label encoding + scaling
│   └── haversine.py            ← GPS distance formula
│
├── models/
│   ├── ml_models.py            ← RF + Gradient Boosting training
│   ├── optimizer.py            ← Hungarian algorithm matching
│   └── kpi.py                  ← KPI computation
│
└── pages/
    ├── 1_Dashboard.py          ← KPI overview + EDA charts
    ├── 2_Map.py                ← Folium geographic map
    ├── 3_ML_Models.py          ← Model results + feature importance
    ├── 4_Matching.py           ← Redistribution match table
    ├── 5_Simulation.py         ← Live simulation loop
    └── 6_Ethics_Architecture.py← Ethics + architecture docs
""", language="text")

    st.subheader("▶️ How to Run")
    st.code("""
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the web app
streamlit run app.py
""", language="bash")
