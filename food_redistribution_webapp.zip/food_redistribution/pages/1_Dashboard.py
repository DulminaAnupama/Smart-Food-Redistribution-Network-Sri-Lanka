"""pages/1_Dashboard.py — KPI Overview"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import streamlit as st
import plotly.express as px

st.set_page_config(page_title="Dashboard", page_icon="📊", layout="wide")
st.title("📊 System Dashboard — KPI Overview")

if "kpis" not in st.session_state:
    st.warning("⚠️ Please run the pipeline from the **Home** page first.")
    st.stop()

kpis      = st.session_state.kpis
suppliers = st.session_state.suppliers
ngos      = st.session_state.ngos
matches   = st.session_state.matches

# KPI cards
icons = ["📦","🚚","⚡","🍽️","📍","♻️","🏪","🏥","✅"]
cols  = st.columns(3)
for i, (k, v) in enumerate(kpis.items()):
    cols[i % 3].metric(f"{icons[i]}  {k}", f"{v:,}" if isinstance(v, int) else v)

st.divider()

c1, c2 = st.columns(2)
with c1:
    st.subheader("🏙️ Average Surplus by City")
    city_df = suppliers.groupby("city")["surplus_food"].mean().reset_index().sort_values("surplus_food")
    fig = px.bar(city_df, x="surplus_food", y="city", orientation="h",
                 color="surplus_food", color_continuous_scale="Greens",
                 template="plotly_dark", labels={"surplus_food":"Avg Surplus (kg)","city":"City"})
    fig.update_layout(coloraxis_showscale=False, height=360, margin=dict(l=0,r=0,t=10,b=0))
    st.plotly_chart(fig, use_container_width=True)

with c2:
    st.subheader("📅 Monthly Surplus Trend")
    month_names = {1:"Jan",2:"Feb",3:"Mar",4:"Apr",5:"May",6:"Jun",
                   7:"Jul",8:"Aug",9:"Sep",10:"Oct",11:"Nov",12:"Dec"}
    month_df = suppliers.groupby("month")["surplus_food"].mean().reset_index()
    month_df["Month"] = month_df["month"].map(month_names)
    fig2 = px.line(month_df, x="Month", y="surplus_food", markers=True,
                   template="plotly_dark", color_discrete_sequence=["#00ffa3"],
                   labels={"surplus_food":"Avg Surplus (kg)"})
    fig2.update_traces(line_width=2.5, marker_size=8)
    fig2.update_layout(height=360, margin=dict(l=0,r=0,t=10,b=0))
    st.plotly_chart(fig2, use_container_width=True)

c3, c4, c5 = st.columns(3)
with c3:
    st.subheader("🏪 By Supplier Type")
    type_df = suppliers.groupby("type")["surplus_food"].mean().reset_index()
    fig3 = px.pie(type_df, values="surplus_food", names="type", template="plotly_dark",
                  hole=0.5, color_discrete_sequence=["#00ffa3","#22c55e","#a3e635"])
    fig3.update_layout(height=300, margin=dict(l=0,r=0,t=10,b=0))
    st.plotly_chart(fig3, use_container_width=True)

with c4:
    st.subheader("🥗 By Food Type")
    food_df = suppliers.groupby("food_type")["surplus_food"].mean().reset_index().sort_values("surplus_food")
    fig4 = px.bar(food_df, x="surplus_food", y="food_type", orientation="h",
                  template="plotly_dark", color_discrete_sequence=["#f97316"],
                  labels={"surplus_food":"Avg Surplus (kg)","food_type":"Food Type"})
    fig4.update_layout(height=300, margin=dict(l=0,r=0,t=10,b=0))
    st.plotly_chart(fig4, use_container_width=True)

with c5:
    st.subheader("🏥 NGO Urgency Levels")
    urg_df = ngos["urgency_level"].value_counts().reset_index()
    urg_df.columns = ["Urgency","Count"]
    urg_df["Label"] = urg_df["Urgency"].map({1:"Low",2:"Medium",3:"High"})
    fig5 = px.pie(urg_df, values="Count", names="Label", template="plotly_dark",
                  color_discrete_sequence=["#22c55e","#f97316","#ef4444"])
    fig5.update_layout(height=300, margin=dict(l=0,r=0,t=10,b=0))
    st.plotly_chart(fig5, use_container_width=True)

st.subheader("📊 Surplus Distribution Histogram")
fig6 = px.histogram(suppliers, x="surplus_food", nbins=40, template="plotly_dark",
                    color_discrete_sequence=["#00ffa3"],
                    labels={"surplus_food":"Surplus (kg)"})
fig6.add_vline(x=suppliers["surplus_food"].mean(), line_dash="dash",
               line_color="#f97316", annotation_text="Mean")
fig6.update_layout(height=300, margin=dict(l=0,r=0,t=10,b=0))
st.plotly_chart(fig6, use_container_width=True)
