"""pages/4_Matching.py — Redistribution Optimization Results"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import streamlit as st
import plotly.express as px
import pandas as pd

st.set_page_config(page_title="Matching", page_icon="🔗", layout="wide")
st.title("🔗 Redistribution Optimization — Hungarian Algorithm")

if "matches" not in st.session_state:
    st.warning("⚠️ Please run the pipeline from the **Home** page first.")
    st.stop()

matches = st.session_state.matches

if matches.empty:
    st.error("No matches found.")
    st.stop()

# Summary metrics
c1, c2, c3, c4 = st.columns(4)
c1.metric("Total Matches",    len(matches))
c2.metric("Total Allocated",  f"{matches['allocated_kg'].sum():.0f} kg")
c3.metric("Avg Distance",     f"{matches['distance_km'].mean():.2f} km")
c4.metric("Food Compatible",  f"{matches['food_compatible'].mean()*100:.1f}%")

st.divider()

# Filters
col1, col2, col3 = st.columns(3)
with col1:
    city_filter = st.selectbox("Filter Supplier City", ["All"] + sorted(matches["supplier_city"].unique().tolist()))
with col2:
    urg_filter = st.selectbox("Filter NGO Urgency", ["All","1 - Low","2 - Medium","3 - High"])
with col3:
    compat_filter = st.checkbox("Compatible food only", value=False)

filtered = matches.copy()
if city_filter != "All":
    filtered = filtered[filtered["supplier_city"] == city_filter]
if urg_filter != "All":
    lvl = int(urg_filter[0])
    filtered = filtered[filtered["urgency_level"] == lvl]
if compat_filter:
    filtered = filtered[filtered["food_compatible"]]

# Styled table
st.subheader(f"📋 Match Results ({len(filtered)} rows)")
display = filtered[[
    "supplier_id","supplier_city","ngo_id","ngo_city",
    "food_type","surplus_available","allocated_kg","distance_km",
    "urgency_level","food_compatible"
]].copy()
display["urgency_level"] = display["urgency_level"].map({1:"🟢 Low",2:"🟠 Medium",3:"🔴 High"})
display["food_compatible"] = display["food_compatible"].map({True:"✅ Yes", False:"❌ No"})
st.dataframe(display, use_container_width=True, height=380)

st.download_button(
    "⬇️ Download Matches CSV",
    data=filtered.to_csv(index=False),
    file_name="matches.csv", mime="text/csv"
)

st.divider()
c5, c6 = st.columns(2)

with c5:
    st.subheader("📦 Allocated kg by City")
    city_alloc = matches.groupby("supplier_city")["allocated_kg"].sum().reset_index().sort_values("allocated_kg")
    fig1 = px.bar(city_alloc, x="allocated_kg", y="supplier_city", orientation="h",
                  template="plotly_dark", color_discrete_sequence=["#22c55e"],
                  labels={"allocated_kg":"Allocated (kg)","supplier_city":"City"})
    fig1.update_layout(height=320, margin=dict(l=0,r=0,t=10,b=0))
    st.plotly_chart(fig1, use_container_width=True)

with c6:
    st.subheader("📍 Distance Distribution")
    fig2 = px.histogram(matches, x="distance_km", nbins=25, template="plotly_dark",
                        color_discrete_sequence=["#00ffa3"],
                        labels={"distance_km":"Distance (km)"})
    fig2.update_layout(height=320, margin=dict(l=0,r=0,t=10,b=0))
    st.plotly_chart(fig2, use_container_width=True)

st.subheader("🥗 Allocation by Food Type")
food_alloc = matches.groupby("food_type")["allocated_kg"].sum().reset_index()
fig3 = px.pie(food_alloc, values="allocated_kg", names="food_type",
              template="plotly_dark", hole=0.4,
              color_discrete_sequence=["#00ffa3","#22c55e","#a3e635","#f97316","#ef4444"])
fig3.update_layout(height=320, margin=dict(l=0,r=0,t=10,b=0))
st.plotly_chart(fig3, use_container_width=True)
