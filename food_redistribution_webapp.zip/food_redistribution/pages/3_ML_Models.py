"""pages/3_ML_Models.py — ML Training Results"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import math

st.set_page_config(page_title="ML Models", page_icon="🤖", layout="wide")
st.title("🤖 Machine Learning — Surplus Prediction Models")

if "rf_results" not in st.session_state:
    st.warning("⚠️ Please run the pipeline from the **Home** page first.")
    st.stop()

rf_r      = st.session_state.rf_results
gb_r      = st.session_state.gb_results
best_name = st.session_state.best_name
fi        = st.session_state.feature_importance

# Model comparison cards
st.subheader("📊 Model Performance Comparison")
c1, c2 = st.columns(2)

def model_card(col, results, is_best):
    label = "✦ SELECTED — Best Model" if is_best else "Random Forest"
    col.markdown(f"### {'🏆 Gradient Boosting' if is_best else '🌲 Random Forest'}")
    if is_best:
        col.success(label)
    df = pd.DataFrame([
        {"Metric":"MAE (kg)", "Value": results["MAE"]},
        {"Metric":"RMSE (kg)", "Value": results["RMSE"]},
        {"Metric":"R² Score", "Value": results["R2"]},
    ])
    col.dataframe(df, use_container_width=True, hide_index=True)

with c1:
    model_card(c1, rf_r, best_name == "Random Forest")
with c2:
    model_card(c2, gb_r, best_name == "Gradient Boosting")

# Radar comparison
st.subheader("📡 Model Comparison Radar")
categories = ["R² Score", "Low MAE", "Low RMSE"]
rf_vals  = [rf_r["R2"], 1 - rf_r["MAE"]/20, 1 - rf_r["RMSE"]/20]
gb_vals  = [gb_r["R2"], 1 - gb_r["MAE"]/20, 1 - gb_r["RMSE"]/20]

fig_radar = go.Figure()
fig_radar.add_trace(go.Scatterpolar(r=rf_vals+[rf_vals[0]], theta=categories+[categories[0]],
    fill="toself", name="Random Forest", line_color="#22c55e"))
fig_radar.add_trace(go.Scatterpolar(r=gb_vals+[gb_vals[0]], theta=categories+[categories[0]],
    fill="toself", name="Gradient Boosting", line_color="#00ffa3"))
fig_radar.update_layout(polar=dict(radialaxis=dict(visible=True, range=[0,1])),
    template="plotly_dark", height=380)
st.plotly_chart(fig_radar, use_container_width=True)

# Feature Importance
st.subheader("📊 Feature Importances — Random Forest")
fi_df = pd.DataFrame(fi, columns=["Feature","Importance"]).sort_values("Importance")
fig_fi = px.bar(fi_df, x="Importance", y="Feature", orientation="h",
                template="plotly_dark", color="Importance",
                color_continuous_scale=[[0,"#1e3025"],[1,"#00ffa3"]],
                labels={"Importance":"Importance Score"})
fig_fi.update_layout(coloraxis_showscale=False, height=400, margin=dict(l=0,r=0,t=10,b=0))
st.plotly_chart(fig_fi, use_container_width=True)

# Actual vs Predicted
st.subheader("🎯 Actual vs Predicted Surplus (Test Set)")
suppliers_proc = st.session_state.suppliers_proc
from config import FEATURE_COLS
X_test = st.session_state.X_test
y_test = st.session_state.y_test
best_model = st.session_state.best_model
scaler     = st.session_state.scaler

y_pred = best_model.predict(X_test)
scatter_df = pd.DataFrame({"Actual": y_test, "Predicted": y_pred})
fig_sc = px.scatter(scatter_df, x="Actual", y="Predicted",
                    template="plotly_dark", color_discrete_sequence=["#00ffa3"],
                    labels={"Actual":"Actual Surplus (kg)", "Predicted":"Predicted Surplus (kg)"})
max_val = max(scatter_df["Actual"].max(), scatter_df["Predicted"].max())
fig_sc.add_shape(type="line", x0=0, y0=0, x1=max_val, y1=max_val,
                 line=dict(color="#f97316", dash="dash"), name="Perfect Fit")
fig_sc.update_layout(height=400, margin=dict(l=0,r=0,t=10,b=0))
st.plotly_chart(fig_sc, use_container_width=True)

# Residuals
st.subheader("📉 Residuals Distribution")
residuals = y_test - y_pred
fig_res = px.histogram(x=residuals, nbins=30, template="plotly_dark",
                       color_discrete_sequence=["#a3e635"],
                       labels={"x":"Residual (kg)","y":"Count"})
fig_res.add_vline(x=0, line_dash="dash", line_color="#f97316")
fig_res.update_layout(height=280, margin=dict(l=0,r=0,t=10,b=0))
st.plotly_chart(fig_res, use_container_width=True)
