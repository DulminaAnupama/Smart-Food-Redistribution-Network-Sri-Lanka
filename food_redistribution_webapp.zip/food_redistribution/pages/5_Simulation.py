"""pages/5_Simulation.py — Real-Time Simulation"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import streamlit as st
import numpy as np
import pandas as pd
import time
import plotly.graph_objects as go
from utils.haversine import haversine
from config import CITIES, SUPPLIER_TYPES, FOOD_TYPES, SEASONS, BASE_PRODUCTION, SURPLUS_THRESHOLD_KG, AVG_MEAL_WEIGHT_KG, FEATURE_COLS
from models.ml_models import predict_surplus
from models.optimizer import optimize_matching

st.set_page_config(page_title="Simulation", page_icon="⚡", layout="wide")
st.title("⚡ Real-Time Redistribution Simulation")
st.caption("Live ML prediction → Hungarian matching → dispatch")

if "best_model" not in st.session_state:
    st.warning("⚠️ Please run the pipeline from the **Home** page first.")
    st.stop()

best_model = st.session_state.best_model
scaler     = st.session_state.scaler
le_type    = st.session_state.le_type
le_food    = st.session_state.le_food
le_season  = st.session_state.le_season
ngos       = st.session_state.ngos

# Controls
c1, c2, c3 = st.columns(3)
n_steps  = c1.slider("Number of Simulation Steps", 5, 50, 15)
delay_ms = c2.slider("Step Delay (ms)", 0, 1000, 300)
seed     = c3.number_input("Random Seed", value=999, step=1)

run_btn   = st.button("▶ Run Simulation", type="primary")
clear_btn = st.button("🗑 Clear")

# Live counters
kpi_cols = st.columns(4)
steps_ph     = kpi_cols[0].empty()
dispatch_ph  = kpi_cols[1].empty()
meals_ph     = kpi_cols[2].empty()
kg_ph        = kpi_cols[3].empty()

def refresh_kpis(steps, dispatched, meals, kg):
    steps_ph.metric("Steps Run",     steps)
    dispatch_ph.metric("Dispatched", dispatched)
    meals_ph.metric("Meals Saved",   f"{meals:,}")
    kg_ph.metric("kg Allocated",     f"{kg:.0f}")

refresh_kpis(0,0,0,0)

log_ph   = st.empty()
chart_ph = st.empty()

if "sim_log" not in st.session_state:
    st.session_state.sim_log = []

if clear_btn:
    st.session_state.sim_log = []
    refresh_kpis(0,0,0,0)

if run_btn:
    st.session_state.sim_log = []
    np.random.seed(int(seed))
    city_names = list(CITIES.keys())
    total_steps = 0; total_dispatched = 0; total_meals = 0; total_kg = 0.0
    surplus_history = []

    for step in range(1, n_steps + 1):
        city     = np.random.choice(city_names)
        lat, lon, density = CITIES[city]
        stype    = np.random.choice(SUPPLIER_TYPES, p=[0.5, 0.3, 0.2])
        ftype    = np.random.choice(FOOD_TYPES)
        month    = int(np.random.randint(1, 13))
        dow      = int(np.random.randint(0, 7))
        season   = SEASONS[(month % 12) // 3]
        produced = max(20.0, BASE_PRODUCTION[stype] + np.random.normal(0, 20))
        sell_pct = float(np.clip(0.55 + 0.25 * density + np.random.normal(0, 0.08), 0.30, 0.95))
        sold     = produced * sell_pct

        encoded_row = {
            "type_enc":            int(le_type.transform([stype])[0]),
            "food_enc":            int(le_food.transform([ftype])[0]),
            "daily_food_produced": round(produced, 1),
            "daily_food_sold":     round(sold, 1),
            "day_of_week":         dow,
            "month":               month,
            "season_enc":          int(le_season.transform([season])[0]),
            "population_density":  density,
            "latitude":            lat,
            "longitude":           lon,
        }

        pred = predict_surplus(best_model, scaler, encoded_row, FEATURE_COLS)
        surplus_history.append({"Step": step, "Predicted Surplus (kg)": pred, "City": city})
        total_steps = step

        if pred >= SURPLUS_THRESHOLD_KG:
            sim_sup = pd.DataFrame([{
                "supplier_id": f"SIM_{step:02d}", "type": stype, "city": city,
                "latitude": lat, "longitude": lon, "food_type": ftype,
                "daily_food_produced": round(produced,1), "daily_food_sold": round(sold,1),
                "surplus_food": pred, "population_density": density,
            }])
            sim_matches = optimize_matching(sim_sup, ngos)
            if not sim_matches.empty:
                m = sim_matches.iloc[0]
                meals = int(round(m.allocated_kg / AVG_MEAL_WEIGHT_KG))
                total_dispatched += 1; total_meals += meals; total_kg += m.allocated_kg
                status = "✅ DISPATCHED"
                detail = f"→ {m.ngo_id} ({m.ngo_city}) | {m.allocated_kg:.1f} kg | {m.distance_km:.1f} km | {meals} meals"
                color  = "success"
            else:
                status = "⚠️ No NGO Available"; detail = ""; color = "warning"
        else:
            status = "⏸ Below Threshold"
            detail = f"({pred:.1f} kg < {SURPLUS_THRESHOLD_KG} kg)"
            color  = "info"

        st.session_state.sim_log.append({
            "step": step, "city": city, "type": stype, "surplus": f"{pred:.1f} kg",
            "status": status, "detail": detail, "color": color
        })

        refresh_kpis(total_steps, total_dispatched, total_meals, total_kg)

        # Render log
        with log_ph.container():
            st.subheader("📋 Simulation Log")
            for entry in reversed(st.session_state.sim_log[-20:]):
                fn = getattr(st, entry["color"])
                fn(f"**Step {entry['step']:02d}** | `{entry['city']}` | `{entry['type']}` | "
                   f"Pred: **{entry['surplus']}** | {entry['status']}  {entry['detail']}")

        # Live chart
        if len(surplus_history) > 1:
            df_chart = pd.DataFrame(surplus_history)
            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=df_chart["Step"], y=df_chart["Predicted Surplus (kg)"],
                mode="lines+markers", line=dict(color="#00ffa3", width=2),
                marker=dict(size=7), name="Predicted Surplus"
            ))
            fig.add_hline(y=SURPLUS_THRESHOLD_KG, line_dash="dash",
                          line_color="#f97316", annotation_text="Threshold")
            fig.update_layout(template="plotly_dark", height=280,
                              xaxis_title="Step", yaxis_title="Surplus (kg)",
                              margin=dict(l=0,r=0,t=10,b=0))
            chart_ph.plotly_chart(fig, use_container_width=True)

        time.sleep(delay_ms / 1000)

    st.success(f"✅ Simulation complete! {total_dispatched}/{n_steps} dispatched · {total_meals:,} meals saved · {total_kg:.0f} kg allocated")

elif st.session_state.sim_log:
    with log_ph.container():
        st.subheader("📋 Last Simulation Log")
        for entry in reversed(st.session_state.sim_log[-20:]):
            fn = getattr(st, entry["color"])
            fn(f"**Step {entry['step']:02d}** | `{entry['city']}` | `{entry['type']}` | "
               f"Pred: **{entry['surplus']}** | {entry['status']}  {entry['detail']}")
