# Smart Food Redistribution Network — Sri Lanka
## UN SDG 2: Zero Hunger | AI-Powered Web App

### Setup & Run
```bash
# 1. Install dependencies (one-time)
pip install -r requirements.txt

# 2. Launch the web app
streamlit run app.py
```
Then open http://localhost:8501 in your browser.

### File Structure
```
food_redistribution/
├── app.py                      ← ENTRY POINT — run this
├── config.py                   ← City data, constants, feature list
├── requirements.txt            ← pip dependencies
├── README.md                   ← This file
│
├── utils/
│   ├── data_generator.py       ← Synthetic supplier & NGO data
│   ├── preprocessing.py        ← Label encoding + StandardScaler
│   └── haversine.py            ← GPS great-circle distance
│
├── models/
│   ├── ml_models.py            ← Random Forest + Gradient Boosting
│   ├── optimizer.py            ← Hungarian algorithm matching
│   └── kpi.py                  ← KPI & social impact metrics
│
└── pages/
    ├── 1_Dashboard.py          ← KPI cards + EDA charts
    ├── 2_Map.py                ← Interactive Folium map
    ├── 3_ML_Models.py          ← Model comparison + feature importance
    ├── 4_Matching.py           ← Redistribution match table
    ├── 5_Simulation.py         ← Live step-by-step simulation
    └── 6_Ethics_Architecture.py← Ethics + system architecture
```

### Pages
| Page | What you see |
|------|-------------|
| 🏠 Home | Run the pipeline, see quick summary |
| 📊 Dashboard | KPI metrics, city/month/type charts |
| 🗺️ Map | Folium map with suppliers, NGOs, routes |
| 🤖 ML Models | RF vs GB comparison, feature importance, residuals |
| 🔗 Matching | Full match table with filters + CSV download |
| ⚡ Simulation | Live step-by-step dispatch simulation |
| ⚖️ Ethics | Ethical framework + architecture diagram |
